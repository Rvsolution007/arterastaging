const DOCUMENTATION_OPTIONS = {
    VERSION: '11.9.0',
    LANGUAGE: 'en',
    COLLAPSE_INDEX: false,
    BUILDER: 'singlehtml',
    FILE_SUFFIX: '.html',
    LINK_SUFFIX: '.html',
    HAS_SOURCE: true,
    SOURCELINK_SUFFIX: '.txt',
    NAVIGATION_WITH_KEYS: false,
    SHOW_SEARCH_SUMMARY: true,
    ENABLE_SEARCH_SHORTCUTS: true,
};